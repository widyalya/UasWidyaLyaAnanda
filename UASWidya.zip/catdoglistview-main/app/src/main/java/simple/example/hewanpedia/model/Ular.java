package simple.example.hewanpedia.model;


public class Ular extends Hewan {


    public Ular(String ras, String asal, String deskripsi, int drawableRes) {
        super("Ular",ras,asal,deskripsi,drawableRes);
    }

}
