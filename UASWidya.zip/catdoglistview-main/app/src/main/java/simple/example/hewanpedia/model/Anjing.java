package simple.example.hewanpedia.model;

public class Anjing extends Hewan{

    public Anjing(String ras, String asal, String deskripsi, int drawableRes) {
        super("Anjing",ras,asal,deskripsi,drawableRes);

    }

}
