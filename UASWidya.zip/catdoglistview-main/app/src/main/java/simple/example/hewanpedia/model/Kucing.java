package simple.example.hewanpedia.model;


public class Kucing extends Hewan {


    public Kucing(String ras, String asal, String deskripsi, int drawableRes) {
        super("Kucing",ras,asal,deskripsi,drawableRes);
    }

}
